<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title><?php echo CHtml::encode($this->pageTitle); ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/css/style.css" media="screen, projection" />
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/form.css" />
</head>
<body>
<div id="container">
  <div id="header">
		<?php $this->widget('zii.widgets.CMenu',array(
			'items'=>array(
				array('label'=>'Home', 'url'=>array('/site/index')),
				array('label'=>'Contact', 'url'=>array('/site/contact')),
				array('label'=>'Login', 'url'=>array('/site/login'), 'visible'=>Yii::app()->user->isGuest),
				array('label'=>'Logout ('.Yii::app()->user->name.')', 'url'=>array('/site/logout'), 'visible'=>!Yii::app()->user->isGuest)
			),
		)); ?>
  </div>
  <div id="content">
        <?php echo $content; ?>
  </div>
  <!--
  <div id="welcome">
    <h3>Welcome</h3>
    <p>Don't forgot to check free website templates every day, because we add at least one free website template daily.</p>
    <p>This is a template designed by free website templates for you for free you can replace all the text by your own 
      text. This is just a place holder so you can see how the site would look like.</p>
    <p>You can remove any link to our websites from this template you're  free to use the template without linking 
      back to us.</p>
    <p>If you're having problems editing the template please don't hesitate to ask for help on the forum.</p>
    <br />
    <br />
  </div>
  -->
  <div id="news">
   
</div>
</body>
</html>
