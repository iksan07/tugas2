<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

<h1>Selamat datang di Website Saya</h1>

<a href="/yii/index.php?r=users/index"><h4>Klik ini Untuk Melihat tabel saya</h4></a>
<a href="/yii/index.php?r=users/create"><h4>Klik ini Untuk Menambah Mahasiswa</h4></a>

