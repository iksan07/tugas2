<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

<h3>MENGISI BIODATA</h3>

<a href="/yii/index.php?r=users/index"><center><h2>Klik ini Untuk Melihat Hasil pendaftaran</h2></a></center>
<a href="/yii/index.php?r=users/create"><center><h2>Klik disini Untuk Mendaftar</h2></a></center>

