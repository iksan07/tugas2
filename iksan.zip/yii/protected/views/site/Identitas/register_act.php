<?php
//register_act.php

include "cek_login.php";
$username = $_POST['username'];
$name = $_POST['name'];
$password= $_POST['password'];
$confirm = $_POST['confirm'];
$submit = $_POST['submit'];

if ($submit){
//untuk mengecek apakah ada form yang kosong
if ($username&&$name&&$password&&$confirm){
//untuk mencocokan passwordnya
if ($password==$confirm){
//menentukan panjang username dan name
if (strlen($username)>30||strlen($name)>30){
     ?>
            <script>alert("Usernmae dan nama anda tidak boleh melebihi batas 30 kata!");document.location="register_index.php";</script>
            <?php

}
else {
//menentukan panjang passwordnya
if (strlen($password)>25|| strlen($confirm)<6){
    ?>
            <script>alert("Password Anda Kurang Panjang Minimal '6' Huruf!");document.location="register_index.php";</script>
            <?php

}
else {
//menampilkan data dari database
$get_reg = mysql_query("SELECT * FROM user WHERE username='$username'");
$num_reg = mysql_num_rows($get_reg);
//untuk mengecek apakah username sudah ada
if ($num_reg!=0){
    ?>
            <script>alert("Maaf, Username telah ada di dalan database!");document.location="register_index.php";</script>
            <?php
}
else {
$password = md5($password);
$confirm = md5 ($confirm);
//untuk memasukan data ke database
$insert_reg = mysql_query("INSERT INTO user VALUES ('','$username','$name','$password','$confirm','')");
?>
            <script>alert("Selamat Registrasi Anda Sukses!");document.location="login.php";</script>
            <?php

}

}
}

}
else {
    ?>
            <script>alert("Periksa Password Anda!");document.location="register_index.php";</script>
            <?php

}
}
else {
    ?>
            <script>alert("Lengkapi Data Anda!");document.location="register_index.php";</script>
            <?php

}
}

?>