<?php

//db.php
$host ="localhost";
$user ="root";
$pass = "";
$dbname = "login_id";
//untuk mengkoneksikan ke database
$sql_connect= mysql_connect($host, $user, $pass)or die ("fialed to connect database".mysql_error());
$open_db= mysql_select_db($dbname) or die("failed to open database name");
?>