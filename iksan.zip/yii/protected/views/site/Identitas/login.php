<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    </head>
    <body>
        <form name="login" method="Post" Action="login_act.php">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div  class="modal-header">
                        <div class="modal-title"><h3>Silahkan Login</h3></div>
                    </div>
                    <div class="modal-body">
                        <div class="input-group">
                            <div class="input-group-addon"><i class="glyphicon glyphicon-user"></i></div>
                            <input class="form-control" type="text" name="username" placeholder="Username" required="">
                        </div>
                        <br>
                        <div class="input-group">
                            <div class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></div>
                            <input class="form-control" type="password" name="password" placeholder="Password" required="">
                        </div>
                        <br>                   
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="submit" class="btn btn-primary" value="login"><i class="glyphicon glyphicon-ok "> </i> Login</button>
                         <a href="register.php"class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-plus"></i>&nbsp;Buat Akun</a>
                    </div>
                </div>
            </div>
            </form>
    </body>
</html>

