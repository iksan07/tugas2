<?php
// Create database connection using config file
include_once("config.php");
 
// Fetch all users data from database
$result = mysqli_query($mysqli, "SELECT * FROM users ORDER BY id DESC");
?>
<html>
    <head>
         <link rel="stylesheet" type="text/css" href="form.css">
    </head>
    <body>
       <div class="panel-group">
            <div class="panel panel-default">
                <div class="panel-heading">
                   <div class="row">
                        <div class="col-lg-7">
                            <i class="glyphicon glyphicon-new-window"></i>&nbsp;Profil
                        </div>
                       <div class="col-lg-5">
                          
                        </div>
                        </div>
                </div>
                <div class="panel-body">
                     <div class="table table-responsive">
                        <table>
                           
             
                                
                            
                                    
    <?php  
    
    while($user_data = mysqli_fetch_array($result)) {         
        echo "<center><tr>";
        echo "<p><b>Nama   :  </b>  ".$user_data['name']."</P>";
            echo "<p><b>Alamat :  </b>".$user_data['Alamat']."</p>";
            echo "<p><b>Umur     :</b>  ".$user_data['Umur']."</p>";
            echo "<p><b>Pekerjaan:</b>".$user_data['Pekerjaan']."</p>";
            echo "<p><b>Status  : </b>".$user_data['Status'   ]."</p>";
            echo "<p><b>Mobile  : </b>".$user_data['mobile']."</p>";
            echo "<p><b>Email   : </b>".$user_data['email']."</p>";    
            echo " <a href='delete.php?id=$user_data[id]'>Delete</a></tr></center>";       
    }
    ?>
                                    
    
    </table>

 
   
<?php  
    while($user_data = mysqli_fetch_array($result)) {         
        echo "<center>";
            echo "<p><b>Nama   :  </b>  ".$user_data['name']."</P>";
            echo "<p><b>Alamat :  </b>".$user_data['Alamat']."</p>";
            echo "<p><b>Umur     :</b>  ".$user_data['Umur']."</p>";
            echo "<p><b>Pekerjaan:</b>".$user_data['Pekerjaan']."</p>";
            echo "<p><b>Status  : </b>".$user_data['Status']."</p>";
            echo "<p><b>Mobile  : </b>".$user_data['mobile']."</p>";
            echo "<p><b>Email   : </b>".$user_data['email']."</p>";    
            echo "<a href='edit.php?id=$user_data[id]'>Edit</a> | <a href='delete.php?id=$user_data[id]'>Delete</a> |<a href='delete.php?id=$user_data[id]'>Print</a></center>";        
    }
    ?>

	
                            </tbody>
                                
                        </table>
                    </div>
                </div>
                <div class="panel-footer">
                    <button data-toggle="modal" data-target="#forminput" class="btn btn-sm btn-info"><i class="glyphicon glyphicon-plus"></i>&nbsp;Tambah</button>
                      <button onClick="window.print();"a class="btn btn-sm btn-success"  target="_blank"><i class="glyphicon glyphicon-print"></i>&nbsp;Cetak</a></button>
                        
                </div>
            </div>
        </div>
     <?php
 
	// Check If form submitted, insert form data into users table.
	if(isset($_POST['Submit'])) {
		$Nama = $_POST['Nama'];
                $Alamat = $_POST['Alamat'];
                $Umur = $_POST['Umur'];
                $Pekerjaan = $_POST['Pekerjaan'];
                $status = $_POST['status'];
		$email = $_POST['email'];
		$mobile = $_POST['mobile'];
		
		// include database connection file
		include_once("config.php");
				
		// Insert user data into table
		$result = mysqli_query($mysqli, "INSERT INTO users(name,Alamat,Umur,Pekerjaan,status,email,mobile) VALUES('$Nama','$Alamat','$Umur','$Pekerjaan','$status','$email','$mobile')");
		
		// Show message when user added
		echo "Identitas Anda Telah Di Tambahkan. <a href='index.php'>Tampilkan</a>";
	}
	?>
            
            <div class="modal fade" id="forminput" role="dialog">
                <div class="modal-dialog modal-sm">
                    <form name="input" method="post">
                        <div class="modal-content">
                            <div class="modal-header">Kartu Nama</div>
                       
                        <div class="modal-body">
                            <div class="input-group" style="margin-bottom: 3px">
                                <div class="input-group-addon"><i class="glyphicon"></i></div>
                            <input class="form-control" type="text" name="Nama" required placeholder="Nama">
                            </div>
                            <div class="input-group" style="margin-bottom: 3px;">
                                <div class="input-group-addon"><i class="glyphicon"></i></div>
                            <input class="form-control" type="text" name="Alamat" required placeholder="Alamat">
                            </div>
                            
                            <div class="input-group" style="margin-bottom: 3px;">
                                <div class="input-group-addon"><i class="glyphicon"></i></div>
                            <input class="form-control" type="text" name="Umur" required placeholder="Umur">
                            </div>
                            <div class="input-group" style="margin-bottom: 3px;">
                                <div class="input-group-addon"><i class="glyphicon"></i></div>
                            <input class="form-control" type="text" name="Pekerjaan" required placeholder="Pekerjaan">
                            </div>
                            <div class="input-group" style="margin-bottom: 3px;">
                                <div class="input-group-addon"><i class="glyphicon"></i></div>
                            <input class="form-control" type="text" name="status" required placeholder="status">
                            </div>
                            <div class="input-group" style="margin-bottom: 3px;">
                                <div class="input-group-addon"><i class="glyphicon"></i></div>
                            <input class="form-control" type="text" name="email" required placeholder="email">
                            </div>
                            <div class="input-group" style="margin-bottom: 3px;">
                                <div class="input-group-addon"><i class="glyphicon"></i></div>
                            <input class="form-control" type="text" name="mobile" required placeholder="mobile">
                            </div>            
                            
                </div>
                <div class="modal-footer">
                   <Button input type="submit" name="Submit" value="add"class="btn btn-sm btn-info"><i class="glyphicon glyphicon-save"></i>&nbsp;Simpan</button>
                    
                    <button data-dismiss="modal" class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-refresh"></i>&nbsp;Batal</button>
                        </div>
                     </div>
               </div>
          </form>
    </body>
              
</html>