<html>
    <head>
        <title> </title>
    </head>
    <body style="background-color: #cccccc;">
        
        <h1><center>Biodata :</center></h1>
        <p>
            Nama : &nbsp;<?php echo $_SESSION ['username']; ?>
           
              
        </p>
    </body>
</html>
