<?php
include_once("config.php");
$page = $_GET['page'];
$halaman="$page.php";
if (!file_exists($halaman)){
    require "home.php";
}else{
    include "$halaman";
}
?>
