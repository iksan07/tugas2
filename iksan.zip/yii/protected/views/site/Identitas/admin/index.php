<?php
session_start();
if (!empty($_SESSION['username'])) {
?>
<html>
    <head>
        <title>Buat Identitas</title>
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
        <script src="../bootstrap/js/jquery.min.js"></script>
        <script src="../bootstrap/js/bootstrap.min.js"></script>
        <script src="../bootstrap/js/search.js"></script>
    </head>
    <body>
        <div class="navbar navbar-default">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="navbar-brand">P-Art</div>
        </div>
            <div class="collapse navbar-collapse" id="nav">
                <ul class="nav navbar-nav">
                    
                      </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href=""><i class="glyphicon glyphicon-Refresh"></i>&nbsp;Segarkan</a></li>
                    <li><a href="?page=profile"><i  class="glyphicon glyphicon-user"></i>&nbsp;<?php echo $_SESSION ['username']; ?></a>
                    <li><a href="javascript:;" data-toggle="modal" data-target="#konfirmasi"class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-off"></i>&nbsp;Keluar</a></li>
                </ul>  
               
                
           </div>
        </div>
        <div class="modal fade" id ="konfirmasi" tabindex="-1" role="dialog" arial-labelledby="mymodalLabel" arial-hidden="true">
            
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type ="button" class="close" data-dismiss="modal">
                            <span arial-hidden="true">&times;</span>
                            <span class="sr-only">Close</span>
                        </button>
                        <h4 class="modal-title" id="mymodalLabel">
                             Apakah Anda Yakin Akan Keluar Dari Aplikasi Ini...?
                        </h4>
                    </div>
                    
                    <div class="modal-footer">
                        <a href="security.php" class="btn btn-sm btn-info">Ya</a>
                        <button type="Button"  class="btn btn-sm btn-danger" data-dismiss="modal">
                           Tidak
                        </button>
                    </div>
                        </button>
                    </div>
                </div> 
            </div>
        
<!--             tampilan dalam-->
  
    
                <div class="col-lg-10">
                    <?php include"page.php"; ?>
                </div>
               
                
</body
</html>
<?php
}else{
    header('location:../index.php');
}