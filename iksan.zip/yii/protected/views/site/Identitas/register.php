<!--register.php -->
<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    </head>
    <body>
        <form name="login" method="Post" Action="register_act.php">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div  class="modal-header">
                        <div class="modal-title"><h3>Registrasi</h3></div>
                    </div>
                    <div class="modal-body">
                       <div class="input-group">
                            <div class="input-group-addon"><i class="glyphicon glyphicon-user"></i></div>
                            <input class="form-control" type="text" name="username" placeholder="Masukan Username" required="">
                        </div>
                        <br>
                         <div class="input-group">
                            <div class="input-group-addon"><i class="glyphicon glyphicon-king"></i></div>
                            <input class="form-control" type="text" name="name" placeholder="Masukan Nama" required="">
                        </div>
                        <br>
                         <div class="input-group">
                            <div class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></div>
                            <input class="form-control" type="password" name="password" placeholder="Masukan password" required="">
                        </div>
                        <br>
                        <div class="input-group">
                            <div class="input-group-addon"><i class="glyphicon glyphicon-repeat"></i></div>
                            <input class="form-control" type="password" name="confirm" placeholder="Konfirmasi password" required="">
                        </div>
                        <br>                   
                    </div>
                    <div class="modal-footer">
                        <a href="index.php"class="btn btn-sm btn-info"><i class="glyphicon glyphicon-refresh"></i>&nbsp;Kembali</a>
                        <button type="submit" name="submit" class="btn btn-success" value="Submit"><i class="glyphicon glyphicon-check" > </i> Selesai</button>
                         
                    </div>
                </div>
            </div>
            </form>
    </body>
</html>


v>