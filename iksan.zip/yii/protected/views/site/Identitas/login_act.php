<?php
//code ini digunakan untuk membuat sessionnya
@session_start();
include "cek_login.php";
$username = $_POST['username'];
$password = $_POST['password'];
//untuk mengecek apakah ada form yang kosong
 if ($username&&$password){
 $get_log = mysql_query("SELECT * FROM user WHERE username='$username'");
 $num_log = mysql_num_rows ($get_log);
 //mengecek apakah username ada atau tidak didalam database
 if ($num_log!=0){
 while ($row = mysql_fetch_assoc($get_log)){
 $dbusername = $row['username'];
 $dbpassword = $row['password'];
 }
 //mengecek kebenaran password
 if ($username==$dbusername&&md5($password)==$dbpassword){
 $_SESSION['username']=$username;
 //ini adalah bagian paling penting untuk membuat who's online atau member online.
 //Ini berfungsi mengupdate field online menjadi 1
 $update_log = mysql_query("UPDATE user SET online ='1' WHERE username = '$username'");
 //code ini berfungsi kalau proses login berhasil maka akan langsung di arahkan kehalaman admin/index.php
  ?>
            <script>alert("Selamat Anda Berhasil Login");document.location="admin/index.php?page=home";</script>
            <?php
 exit();

 }
 else {
     ?>
            <script>alert("Password Anda Salah!");document.location="login.php";</script>
            <?php
 }
 }
 else {
      ?>
            <script>alert("Username Anda Belum Tersedia Di Database!");document.location="login.php";</script>
            <?php
 }
 }
 else {
      ?>
            <script>alert("Lengkapi Form Nya!!");document.location="login.php";</script>
            <?php
 }

?>
