<?php

/**
 * This is the model class for table "users".
 *
 * The followings are the available columns in table 'users':
 * @property string $id_user
 * @property string $nama
 * @property string $nim
 * @property string $program_studi
 * @property string $jurusan
 * @property string $alamat
 * @property string $tgl_lahir
 * @property string $status
 * @property string $no_telepon
 * @property string $username
 * @property string $password
 * @property string $level_user
 */
class Users extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'users';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('nama, nim, program_studi, jurusan, alamat, tgl_lahir, status, no_telepon, username, password', 'required'),
			array('nama, username', 'length', 'max'=>200),
			array('nim, program_studi, jurusan, tgl_lahir, status, no_telepon', 'length', 'max'=>20),
			array('alamat', 'length', 'max'=>30),
			array('level_user', 'length', 'max'=>150),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id_user, nama, nim, program_studi, jurusan, alamat, tgl_lahir, status, no_telepon, username, password, level_user', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id_user' => 'Id User',
			'nama' => 'Nama',
			'nim' => 'Nim',
			'program_studi' => 'Program Studi',
			'jurusan' => 'Jurusan',
			'alamat' => 'Alamat',
			'tgl_lahir' => 'Tgl Lahir',
			'status' => 'Status',
			'no_telepon' => 'No Telepon',
			'username' => 'Username',
			'password' => 'Password',
			'level_user' => 'Level User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id_user',$this->id_user,true);
		$criteria->compare('nama',$this->nama,true);
		$criteria->compare('nim',$this->nim,true);
		$criteria->compare('program_studi',$this->program_studi,true);
		$criteria->compare('jurusan',$this->jurusan,true);
		$criteria->compare('alamat',$this->alamat,true);
		$criteria->compare('tgl_lahir',$this->tgl_lahir,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('no_telepon',$this->no_telepon,true);
		$criteria->compare('username',$this->username,true);
		$criteria->compare('password',$this->password,true);
		$criteria->compare('level_user',$this->level_user,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Users the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
